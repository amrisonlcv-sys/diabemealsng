import React from 'react';

interface EbookMockupProps {
  imageUrl: string;
  className?: string;
}

export const EbookMockup: React.FC<EbookMockupProps> = ({ imageUrl, className = "" }) => {
  return (
    <div className={`flex flex-col items-center justify-center p-6 ${className}`}>
      <div className="relative group mb-6">
        {/* Mockup Container - Simplified for pre-rendered 3D images */}
        <div className="relative w-64 md:w-80 transition-transform duration-500 transform group-hover:scale-105 filter drop-shadow-2xl">
           <img 
            src={imageUrl} 
            alt="Study Guide: How to control diabetes using Nigerian foods" 
            className="w-full h-auto object-contain"
          />
        </div>
      </div>
      
      <div className="w-full max-w-xs text-center">
        <div className="text-red-600 font-bold text-lg mb-2 animate-pulse">
           Limited Time Offer: ₦5,000 <span className="text-gray-400 line-through text-sm">₦15,000</span>
        </div>
        <a 
          href="https://selar.com/x0700u31c1" 
          target="_blank" 
          rel="noopener noreferrer"
          className="block w-full bg-green-600 hover:bg-green-700 text-white font-bold text-xl py-4 px-6 rounded-lg shadow-lg transform transition hover:-translate-y-1 hover:shadow-xl border-b-4 border-green-800"
        >
          Download Now
        </a>
        <p className="text-xs text-gray-500 mt-2">Instant PDF Download • Secure Payment via Selar</p>
      </div>
    </div>
  );
};